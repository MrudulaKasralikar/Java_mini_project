import java.util.Scanner;
import java.util.Random;

public class Game {
private int randomNumber;
private int attempts;

public void generateNumber() {
Random rand = new Random();
randomNumber = rand.nextInt(100) + 1; // Random number between 1 and 100
attempts = 0;
}

public String checkGuess(int guess) {
attempts++;
if (guess < randomNumber) {
return "Too low!";
} else if (guess > randomNumber) {
return "Too high!";
} else {
return "Correct!";
}
}

public int getAttempts() {
return attempts;
}
}

public class Main {
public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
Game game = new Game();
game.generateNumber();

System.out.println("Welcome to the Number Guessing Game!");
int guess;
String result;

do {
System.out.print("Enter your guess: ");
guess = sc.nextInt();
result = game.checkGuess(guess);
System.out.println(result);
} while (!result.equals("Correct!"));

System.out.println("You guessed the number in " + game.getAttempts() + " attempts!");
}
}
 
